#pragma once

class Sun
{
	double angle;

public:
	Sun();

	double getAngle();
	void toModelMinute();

};

