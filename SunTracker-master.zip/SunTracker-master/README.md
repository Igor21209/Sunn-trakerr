# SunTracker
 MQTT Sun tracker Client
 
 <--------- Windows CMD -------->
 
 --> To start Broker: 
 mosquitto -p 1884 -v

 --> To subscribe on topic:
 mosquitto_sub -h localhost -p 1884 -t "test/topic"
